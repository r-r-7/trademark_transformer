import time
import logging
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import PredictSerializer
from .models import UserRequest
from .utils import predict_class  # We'll define this later
from django.utils import timezone

# Initialize logger
logger = logging.getLogger('api_logger')

class PredictView(APIView):
    def post(self, request):
        serializer = PredictSerializer(data=request.data)
        if serializer.is_valid():
            user_id = serializer.validated_data['user_id']
            description = serializer.validated_data['description']

            # Log the incoming request
            logger.info(f"Received request from user_id: {user_id} with description: '{description}'")

            # Check for user and update request count
            user_request, created = UserRequest.objects.get_or_create(user_id=user_id)
            if user_request.request_count >= 5:
                logger.warning(f"User {user_id} has exceeded the request limit.")
                return Response({'error': 'Too many requests'}, status=status.HTTP_429_TOO_MANY_REQUESTS)
            
            start_time = time.time()
            predicted_class = predict_class(description)
            end_time = time.time()
            inference_time = end_time - start_time

            # Update user request count and save
            user_request.request_count += 1
            user_request.last_request_time = timezone.now()
            user_request.save()

            response = {
                'predicted_class': predicted_class,
                'inference_time': end_time - start_time
            }

            # Log the successful response with inference time
            logger.info(f"Response for user_id: {user_id} | Predicted Class: {predicted_class} | Inference Time: {inference_time:.4f} seconds")

            return Response(response, status=status.HTTP_200_OK)

        # Log any validation errors
        logger.error(f"Validation error for request data: {request.data} | Errors: {serializer.errors}")
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)