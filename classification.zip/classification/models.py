from django.db import models

# Create your models here.
class UserRequest(models.Model):
    user_id = models.CharField(max_length=100, unique=True)
    request_count = models.IntegerField(default=0)
    last_request_time = models.DateTimeField(auto_now=True)