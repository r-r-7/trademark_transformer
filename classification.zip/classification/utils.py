import torch
from transformers import BertTokenizer, BertModel
from sklearn.preprocessing import LabelEncoder

class TrademarkClassifier(torch.nn.Module):
    def __init__(self, n_classes):
        super(TrademarkClassifier, self).__init__()
        self.bert = BertModel.from_pretrained('bert-base-uncased')
        self.drop = torch.nn.Dropout(p=0.3)
        self.out = torch.nn.Linear(self.bert.config.hidden_size, n_classes)

    def forward(self, input_ids, attention_mask):
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask
        )
        pooled_output = outputs.pooler_output
        output = self.drop(pooled_output)
        return self.out(output)

# Load model and label encoder
checkpoint = torch.load('trademark_classifier_model.pth', map_location=torch.device('cpu'))
model = TrademarkClassifier(n_classes=len(checkpoint['label_encoder'].classes_))
model.load_state_dict(checkpoint['model_state_dict'])
label_encoder = checkpoint['label_encoder']
model.eval()

tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')

def predict_class(description):
    encoding = tokenizer.encode_plus(
        description,
        add_special_tokens=True,
        max_length=128,
        return_token_type_ids=False,
        padding='max_length',
        truncation=True,
        return_attention_mask=True,
        return_tensors='pt',
    )
    input_ids = encoding['input_ids']
    attention_mask = encoding['attention_mask']

    with torch.no_grad():
        output = model(input_ids, attention_mask)
        _, prediction = torch.max(output, dim=1)

    return label_encoder.inverse_transform(prediction.cpu().numpy())[0]